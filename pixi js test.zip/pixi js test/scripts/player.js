class Player{
	constructor(data){
		this.sprite=new PIXI.AnimatedSprite(players.animation.down_idle.animation)
		this.sprite.anchor.set(0.5)
		main_container.addChild(this.sprite)
		this.sprite.scale=data.scale
		this.x=data.x
		this.y=data.y
		this.state=data.state
		this.direction=data.direction
		
	}
	play(data){
		playAnimation({
			sprite:this.sprite,
			src:players.animation,
			name:data.name
		})
	}
	dash(){
		try {
if (this.state != 'dash')
{
	playAnimation({
		sprite: this.sprite,
		src: players.animation,
		name: `dash_${this.direction}`,
	})
	this.state = 'dash'
	players.main.onChange()
}
}catch(e){}
}
  onChange(){}
}
function playerInitialize() {
players.main=new Player({state:'idle',direction:'down',scale:1.8,x:10,y:10})
players.main.play({name:'down_idle',speed:.15,loop:true})
players.main.sprite.onComplete = () => {
	if (players.main.state == 'dash') {
		players.main.state = 'idle'
		playAnimation({
			sprite: players.main.sprite,
			src: players.animation,
			name: `${players.main.direction}_idle`,
			loop: true,
			speed: .15,
		})
		
	}
}
}
