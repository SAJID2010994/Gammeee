let srch = new window.URLSearchParams(window.location.search)
let peer;
let con;
let id=null
let hostId=srch.get('name')
function multiPlayer() {
	
if (srch.get('state') == 'join') {
	peer = new Peer()
	con = peer.connect(hostId)
	con.on('open', () => {
		players[hostId]=new Player({state:'idle',direction:'down',scale:1.8,x:10,y:10})
		players.main.onChange=()=>{
con.send({
	x: players.main.x,
	y: players.main.y,
	direction: players.main.direction,
	state: players.main.state
})
		}
	con.on('data',(data)=>{
		players[hostId].x=data.x
		players[hostId].y=data.y
		if (players[hostId].direction!=data.direction || players[hostId].state!=data.state) {
			players[hostId].play({
	name: data.direction + `_${data.state}`,
	loop: true,
	speed: 0.15
})
players[hostId].state = data.state
players[hostId].direction=data.direction
		}
	})
	})
}
else{
	peer = new Peer()
	peer.on('open',(id)=>{
		console.log(id)
	})
	peer.on('connection',(c)=>{
		console.log('aise')
		id=c.peer
		players[id]=new Player({state:'idle',direction:'down',scale:1.8,x:10,y:10})
		c.on('data',(data)=>{
					players[id].x = data.x
		players[id].y = data.y
		if (players[id].direction != data.direction || players[id].state != data.state) {
			players[id].play({
				name: data.direction + `_${data.state}`
			})
			players[id].state = data.state
			players[id].direction = data.direction
		}
		})
		players.main.onChange = () => {
	c.send({
		x: players.main.x,
		y: players.main.y,
		direction: players.main.direction,
		state: players.main.state,
		id: id
	})
}
	})
}
}